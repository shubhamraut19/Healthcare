package com.example.rohanspc.healthcare.Models;

public class Reminder {
    int hour;
    int minute;
    String message;

    public Reminder(){

    }

    public Reminder(int hour, int minute, String message) {
        this.hour = hour;
        this.minute = minute;
        this.message = message;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
