package com.example.rohanspc.healthcare.Utilities;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.rohanspc.healthcare.Models.Reminder;
import com.example.rohanspc.healthcare.R;

import java.util.ArrayList;

public class RecyclerViewAdapter  extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder>{


    Context mContext;
    ArrayList<Reminder> mReminders;

    public RecyclerViewAdapter(Context mContext, ArrayList<Reminder> mReminders) {
        this.mContext = mContext;
        this.mReminders = mReminders;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        RecyclerViewHolder recyclerViewHolder = new RecyclerViewHolder(view);

        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        String hour = Integer.toString(mReminders.get(position).getHour());
        String min = Integer.toString(mReminders.get(position).getMinute());

        String time = hour + " : " + min;

        holder.timeTextView.setText(time);

        holder.descriptionTextView.setText(mReminders.get(position).getMessage());
    }

    @Override
    public int getItemCount() {
        return mReminders.size();
    }


    public class RecyclerViewHolder extends RecyclerView.ViewHolder{

    TextView timeTextView,descriptionTextView;
    RelativeLayout parentLayout;

    public RecyclerViewHolder(View itemView) {
        super(itemView);

        timeTextView = itemView.findViewById(R.id.timeTextView);
        descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
        parentLayout = itemView.findViewById(R.id.parent_layout);
    }



}



}
