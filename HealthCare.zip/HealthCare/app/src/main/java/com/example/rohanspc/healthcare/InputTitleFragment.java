package com.example.rohanspc.healthcare;

import android.app.DialogFragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

public class InputTitleFragment extends DialogFragment {


    private static final String TAG = "InputTitleFragment";
    private EditText mEditText;
    private TextView okTextView,cancelTextView;

    public interface OnInputListener{
        void sendInput(String input);
    }
    public OnInputListener mOnInputListener;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.dialoglayout,container,false);
        mEditText = v.findViewById(R.id.edit_text_message);
        okTextView = v.findViewById(R.id.ok_text_view);
        cancelTextView = v.findViewById(R.id.cancel_text_view);


        okTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputMessage = mEditText.getText().toString().trim();


                mOnInputListener.sendInput(inputMessage);
                getDialog().dismiss();
            }
        });
        cancelTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                getDialog().dismiss();

            }
        });
        return v;


    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            mOnInputListener = (OnInputListener) getActivity();
        }
        catch (ClassCastException e){
            Log.d(TAG, "onAttach: " + e.getMessage());
        }
    }
}
