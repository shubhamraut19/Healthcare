package com.example.rohanspc.healthcare;

import android.graphics.Canvas;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.rohanspc.healthcare.Models.Reminder;
import com.example.rohanspc.healthcare.Models.User;
import com.example.rohanspc.healthcare.Utilities.RecyclerViewAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class FragmentHome extends Fragment {


    private ProgressBar progressBar;
    private static final String TAG = "FragmentHome";
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    CollectionReference usersReference;
    FirebaseFirestore mRef;
    User user_info;
    private ArrayList<Reminder> mReminders;

    private ArrayList<Reminder> finishedReminders;
    private ArrayList<Reminder> upcomingReminders;

    private TextView progressTextView;
    private RecyclerView recyclerViewPassed,recyclerViewUpcoming;


    View v;




    public FragmentHome() {
    }

    private void getReminders(){

        mReminders.clear();

        usersReference.document(user_info.getUserID()).collection("reminders").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    List<DocumentSnapshot> documentSnapshots = task.getResult().getDocuments();

                    for(DocumentSnapshot doc : documentSnapshots){
                        mReminders.add(doc.toObject(Reminder.class));
                    }
//                    Log.d(TAG, "onComplete: Reminders" + mReminders.toString() + " " + mReminders.size());
                    calculateReminders();

                }
                else{
                    Log.d(TAG, "onComplete: Data retrieval failed");
                }
            }
        });
    }

    private void calculateReminders(){
        Calendar c = Calendar.getInstance();

        finishedReminders = new ArrayList<>();
        upcomingReminders = new ArrayList<>();

        int hour = c.get(Calendar.HOUR_OF_DAY);
        int min = c.get(Calendar.MINUTE);
        String time  = Integer.toString(hour) + Integer.toString(min);
        int time1 = Integer.parseInt(time);
        for(Reminder reminder : mReminders){
            int hour1 = reminder.getHour();
            int min1 = reminder.getMinute();
            String timeString = Integer.toString(hour1) + Integer.toString(min1);

            int time2 = Integer.parseInt(timeString);

            if(time2 > time1){
                upcomingReminders.add(reminder);
            }
            else {
                finishedReminders.add(reminder);
            }

        }
        setupRecyclerView();
    }

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.activity_home_fragment,container,false);
        progressBar = v.findViewById(R.id.progressBar2);
        recyclerViewPassed = v.findViewById(R.id.recycler_view_passed);
        recyclerViewUpcoming = v.findViewById(R.id.recycler_view_upcoming);
        progressTextView = v.findViewById(R.id.timeProgressTextiView);

        user_info = new User();

        progressBar.setMax(2400);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            progressBar.setMin(0);
        }
        progressBar.setProgress(50);
        Log.d(TAG, "onCreateView: user_info" + user_info.toString());
        mReminders = new ArrayList<>();

        mAuth = FirebaseAuth.getInstance();
        mRef = FirebaseFirestore.getInstance();

        usersReference = mRef.collection("Users");

        setupFirebaseAuth();
//        mSeekBar = v.findViewById(R.id.seekbar);


        ViewTreeObserver viewTreeObserver = progressTextView.getViewTreeObserver();

        if(viewTreeObserver.isAlive()){
            viewTreeObserver.addOnGlobalFocusChangeListener(new ViewTreeObserver.OnGlobalFocusChangeListener() {
                @Override
                public void onGlobalFocusChanged(View oldFocus, View newFocus) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        progressBar.getViewTreeObserver().removeOnGlobalFocusChangeListener(this);
                    }
                    float viewWidth = progressBar.getWidth();
                    setupProgressbar(viewWidth);
                }
            });
        }
        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int min = c.get(Calendar.MINUTE);
        String time  = Integer.toString(hour) + Integer.toString(min);
        int time1 = Integer.parseInt(time);


        return v;
    }

    private void setupRecyclerView(){
        RecyclerViewAdapter adapterPassed = new RecyclerViewAdapter(getContext(),finishedReminders);

        RecyclerViewAdapter adapterUpcoming = new RecyclerViewAdapter(getContext(),upcomingReminders);

        if(adapterPassed.getItemCount() == 0){
            recyclerViewPassed.setVisibility(View.GONE);
        }

        if(adapterUpcoming.getItemCount() == 0){
            recyclerViewUpcoming.setVisibility(View.GONE);
        }
        recyclerViewPassed.setAdapter(adapterPassed);
        recyclerViewPassed.setLayoutManager(new LinearLayoutManager(getContext()));


        recyclerViewUpcoming.setAdapter(adapterUpcoming);
        recyclerViewUpcoming.setLayoutManager(new LinearLayoutManager(getContext()));


    }

    private void setupProgressbar(float width){

        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int min = c.get(Calendar.MINUTE);

        String time1 = Integer.toString(hour) + Integer.toString(min);
        String time2 = Integer.toString(hour) + " : " + Integer.toString(min);
        int time = Integer.parseInt(time1);
        Log.d(TAG, "setupProgressbar: time " + time);
        progressBar.setProgress(time);
//        float width = progressBar.getWidth();
        float progress = progressBar.getProgress();


        float percentage = (progress / 2400) * 100;
        float x = (width * percentage) / 100;
        Log.d(TAG, "setupProgressbar: width: " + width + "  progress: " + progress + " percentage: " + percentage );
        x -=
        Log.d(TAG, "setupProgressbar: x: " + x);
        progressTextView.setText(time2);
        progressTextView.animate().translationX(x).setDuration(1000);

    }

    private void getData(FirebaseUser user){
        usersReference.document(user.getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    user_info = task.getResult().toObject(User.class);
                    getReminders();
                }
                else{
                    Log.d(TAG, "onComplete: Data retrieval failed");
                }
            }
        });
        


    }

    private void setupFirebaseAuth(){
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = mAuth.getCurrentUser();
                
                if(user != null){
                    Log.d(TAG, "onAuthStateChanged: SIgned in");
                    getData(mAuth.getCurrentUser());
                }
                else{
                    Log.d(TAG, "onAuthStateChanged: signed out");
                }
            }
        };
        
        
        
    }





    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);

    }

    @Override
    public void onStop() {
        super.onStop();
        if(mAuthListener != null){
            mAuth.removeAuthStateListener(mAuthListener);
        }

    }



}
